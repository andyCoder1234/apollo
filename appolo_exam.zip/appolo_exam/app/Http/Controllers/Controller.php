<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function store() {

        $randomIterations = mt_rand(5, 10);
        for ($i = 0; $i < $randomIterations; $i++) {
            $random = new Random();
            $random->value = Str::random(10);
            $random->save();

        $breakdownIterations = mt_rand(5, 10);
        for ($j = 0; $j < $breakdownIterations; $j++) {
            $breakdown = new Breakdown();
            $breakdown->value = Str::random(5);
            $breakdown->random_id = $random->id;
            $breakdown->save();
        }
     }

     $random = new Random();
     $random->value = Str::random(10);
     $random->save();

      $breakdownIterations = mt_rand(5, 10);
        for ($i = 0; $i < $breakdownIterations; $i++) {
           $breakdown = new Breakdown();
           $breakdown->value = Str::random(5);
            $random->breakdowns()->save($breakdown);
        }
   }

     public function index()
     {
        $randoms = Random::with('breakdowns')->get();
        return view('randoms.index', compact('randoms'));

         $randoms = Random::where('flag', 0)->with('breakdowns')->get();
         return view('randoms.index', compact('randoms'));
     }

     public function updateFlag($id)
     {
       $random = Random::findOrFail($id);
       $random->flag = 1;
       $random->save();
     }

}
